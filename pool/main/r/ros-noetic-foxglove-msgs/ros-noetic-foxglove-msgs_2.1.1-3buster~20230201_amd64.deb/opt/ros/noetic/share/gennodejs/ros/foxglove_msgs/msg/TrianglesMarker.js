// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let KeyValuePair = require('./KeyValuePair.js');
let Color = require('./Color.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class TrianglesMarker {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.frame_id = null;
      this.id = null;
      this.lifetime = null;
      this.frame_locked = null;
      this.metadata = null;
      this.pose = null;
      this.points = null;
      this.color = null;
      this.colors = null;
      this.indices = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('frame_id')) {
        this.frame_id = initObj.frame_id
      }
      else {
        this.frame_id = '';
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = '';
      }
      if (initObj.hasOwnProperty('lifetime')) {
        this.lifetime = initObj.lifetime
      }
      else {
        this.lifetime = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('frame_locked')) {
        this.frame_locked = initObj.frame_locked
      }
      else {
        this.frame_locked = false;
      }
      if (initObj.hasOwnProperty('metadata')) {
        this.metadata = initObj.metadata
      }
      else {
        this.metadata = [];
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('points')) {
        this.points = initObj.points
      }
      else {
        this.points = [];
      }
      if (initObj.hasOwnProperty('color')) {
        this.color = initObj.color
      }
      else {
        this.color = new Color();
      }
      if (initObj.hasOwnProperty('colors')) {
        this.colors = initObj.colors
      }
      else {
        this.colors = [];
      }
      if (initObj.hasOwnProperty('indices')) {
        this.indices = initObj.indices
      }
      else {
        this.indices = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TrianglesMarker
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [frame_id]
    bufferOffset = _serializer.string(obj.frame_id, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.string(obj.id, buffer, bufferOffset);
    // Serialize message field [lifetime]
    bufferOffset = _serializer.duration(obj.lifetime, buffer, bufferOffset);
    // Serialize message field [frame_locked]
    bufferOffset = _serializer.bool(obj.frame_locked, buffer, bufferOffset);
    // Serialize message field [metadata]
    // Serialize the length for message field [metadata]
    bufferOffset = _serializer.uint32(obj.metadata.length, buffer, bufferOffset);
    obj.metadata.forEach((val) => {
      bufferOffset = KeyValuePair.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [points]
    // Serialize the length for message field [points]
    bufferOffset = _serializer.uint32(obj.points.length, buffer, bufferOffset);
    obj.points.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [color]
    bufferOffset = Color.serialize(obj.color, buffer, bufferOffset);
    // Serialize message field [colors]
    // Serialize the length for message field [colors]
    bufferOffset = _serializer.uint32(obj.colors.length, buffer, bufferOffset);
    obj.colors.forEach((val) => {
      bufferOffset = Color.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [indices]
    bufferOffset = _arraySerializer.uint32(obj.indices, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TrianglesMarker
    let len;
    let data = new TrianglesMarker(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [frame_id]
    data.frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lifetime]
    data.lifetime = _deserializer.duration(buffer, bufferOffset);
    // Deserialize message field [frame_locked]
    data.frame_locked = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [metadata]
    // Deserialize array length for message field [metadata]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.metadata = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.metadata[i] = KeyValuePair.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [points]
    // Deserialize array length for message field [points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.points[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [color]
    data.color = Color.deserialize(buffer, bufferOffset);
    // Deserialize message field [colors]
    // Deserialize array length for message field [colors]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.colors = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.colors[i] = Color.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [indices]
    data.indices = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.frame_id);
    length += _getByteLength(object.id);
    object.metadata.forEach((val) => {
      length += KeyValuePair.getMessageSize(val);
    });
    length += 24 * object.points.length;
    length += 32 * object.colors.length;
    length += 4 * object.indices.length;
    return length + 129;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/TrianglesMarker';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f365629c151dfe98b2231f3864f8af4b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/TrianglesMarker
    # A marker representing a set of triangles or a surface tiled by triangles
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of the marker
    time timestamp
    
    # Frame of reference
    string frame_id
    
    # Identifier for the marker. A marker will replace any prior marker on the same topic with the same `id`.
    string id
    
    # Length of time (relative to `timestamp`) after which the marker should be automatically removed. Zero value indicates the marker should remain visible until it is replaced or deleted.
    duration lifetime
    
    # Whether the marker should keep its location in the fixed frame (false) or follow the frame specified in `frame_id` as it moves relative to the fixed frame (true)
    bool frame_locked
    
    # Additional user-provided metadata associated with the marker. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    # Origin of triangles relative to reference frame
    geometry_msgs/Pose pose
    
    # Vertices to use for triangles, interpreted as a list of triples (0-1-2, 3-4-5, ...)
    geometry_msgs/Point[] points
    
    # Solid color to use for the whole shape. One of `color` or `colors` must be provided.
    foxglove_msgs/Color color
    
    # Per-vertex colors (if specified, must have the same length as `points`). One of `color` or `colors` should be provided.
    foxglove_msgs/Color[] colors
    
    # Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.
    # 
    # If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).
    uint32[] indices
    
    ================================================================================
    MSG: foxglove_msgs/KeyValuePair
    # foxglove_msgs/KeyValuePair
    # A key with its associated value
    
    # Generated by https://github.com/foxglove/schemas
    
    # Key
    string key
    
    # Value
    string value
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: foxglove_msgs/Color
    # foxglove_msgs/Color
    # A color in RGBA format
    
    # Generated by https://github.com/foxglove/schemas
    
    # Red value between 0 and 1
    float64 r
    
    # Green value between 0 and 1
    float64 g
    
    # Blue value between 0 and 1
    float64 b
    
    # Alpha value between 0 and 1
    float64 a
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TrianglesMarker(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.frame_id !== undefined) {
      resolved.frame_id = msg.frame_id;
    }
    else {
      resolved.frame_id = ''
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = ''
    }

    if (msg.lifetime !== undefined) {
      resolved.lifetime = msg.lifetime;
    }
    else {
      resolved.lifetime = {secs: 0, nsecs: 0}
    }

    if (msg.frame_locked !== undefined) {
      resolved.frame_locked = msg.frame_locked;
    }
    else {
      resolved.frame_locked = false
    }

    if (msg.metadata !== undefined) {
      resolved.metadata = new Array(msg.metadata.length);
      for (let i = 0; i < resolved.metadata.length; ++i) {
        resolved.metadata[i] = KeyValuePair.Resolve(msg.metadata[i]);
      }
    }
    else {
      resolved.metadata = []
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.points !== undefined) {
      resolved.points = new Array(msg.points.length);
      for (let i = 0; i < resolved.points.length; ++i) {
        resolved.points[i] = geometry_msgs.msg.Point.Resolve(msg.points[i]);
      }
    }
    else {
      resolved.points = []
    }

    if (msg.color !== undefined) {
      resolved.color = Color.Resolve(msg.color)
    }
    else {
      resolved.color = new Color()
    }

    if (msg.colors !== undefined) {
      resolved.colors = new Array(msg.colors.length);
      for (let i = 0; i < resolved.colors.length; ++i) {
        resolved.colors[i] = Color.Resolve(msg.colors[i]);
      }
    }
    else {
      resolved.colors = []
    }

    if (msg.indices !== undefined) {
      resolved.indices = msg.indices;
    }
    else {
      resolved.indices = []
    }

    return resolved;
    }
};

module.exports = TrianglesMarker;
