// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let KeyValuePair = require('./KeyValuePair.js');
let Color = require('./Color.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class CylinderMarker {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.frame_id = null;
      this.id = null;
      this.lifetime = null;
      this.frame_locked = null;
      this.metadata = null;
      this.pose = null;
      this.bottom_radius = null;
      this.top_radius = null;
      this.height = null;
      this.color = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('frame_id')) {
        this.frame_id = initObj.frame_id
      }
      else {
        this.frame_id = '';
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = '';
      }
      if (initObj.hasOwnProperty('lifetime')) {
        this.lifetime = initObj.lifetime
      }
      else {
        this.lifetime = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('frame_locked')) {
        this.frame_locked = initObj.frame_locked
      }
      else {
        this.frame_locked = false;
      }
      if (initObj.hasOwnProperty('metadata')) {
        this.metadata = initObj.metadata
      }
      else {
        this.metadata = [];
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('bottom_radius')) {
        this.bottom_radius = initObj.bottom_radius
      }
      else {
        this.bottom_radius = 0.0;
      }
      if (initObj.hasOwnProperty('top_radius')) {
        this.top_radius = initObj.top_radius
      }
      else {
        this.top_radius = 0.0;
      }
      if (initObj.hasOwnProperty('height')) {
        this.height = initObj.height
      }
      else {
        this.height = 0.0;
      }
      if (initObj.hasOwnProperty('color')) {
        this.color = initObj.color
      }
      else {
        this.color = new Color();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CylinderMarker
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [frame_id]
    bufferOffset = _serializer.string(obj.frame_id, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.string(obj.id, buffer, bufferOffset);
    // Serialize message field [lifetime]
    bufferOffset = _serializer.duration(obj.lifetime, buffer, bufferOffset);
    // Serialize message field [frame_locked]
    bufferOffset = _serializer.bool(obj.frame_locked, buffer, bufferOffset);
    // Serialize message field [metadata]
    // Serialize the length for message field [metadata]
    bufferOffset = _serializer.uint32(obj.metadata.length, buffer, bufferOffset);
    obj.metadata.forEach((val) => {
      bufferOffset = KeyValuePair.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [bottom_radius]
    bufferOffset = _serializer.float64(obj.bottom_radius, buffer, bufferOffset);
    // Serialize message field [top_radius]
    bufferOffset = _serializer.float64(obj.top_radius, buffer, bufferOffset);
    // Serialize message field [height]
    bufferOffset = _serializer.float64(obj.height, buffer, bufferOffset);
    // Serialize message field [color]
    bufferOffset = Color.serialize(obj.color, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CylinderMarker
    let len;
    let data = new CylinderMarker(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [frame_id]
    data.frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lifetime]
    data.lifetime = _deserializer.duration(buffer, bufferOffset);
    // Deserialize message field [frame_locked]
    data.frame_locked = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [metadata]
    // Deserialize array length for message field [metadata]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.metadata = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.metadata[i] = KeyValuePair.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [bottom_radius]
    data.bottom_radius = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [top_radius]
    data.top_radius = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [height]
    data.height = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [color]
    data.color = Color.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.frame_id);
    length += _getByteLength(object.id);
    object.metadata.forEach((val) => {
      length += KeyValuePair.getMessageSize(val);
    });
    return length + 141;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/CylinderMarker';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cc5444b6ee614fc21ef1845f5e417169';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/CylinderMarker
    # A marker representing a cylinder or elliptic cylinder
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of the marker
    time timestamp
    
    # Frame of reference
    string frame_id
    
    # Identifier for the marker. A marker will replace any prior marker on the same topic with the same `id`.
    string id
    
    # Length of time (relative to `timestamp`) after which the marker should be automatically removed. Zero value indicates the marker should remain visible until it is replaced or deleted.
    duration lifetime
    
    # Whether the marker should keep its location in the fixed frame (false) or follow the frame specified in `frame_id` as it moves relative to the fixed frame (true)
    bool frame_locked
    
    # Additional user-provided metadata associated with the marker. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    # Position of the center of the cylinder and orientation of the cylinder. The cylinder's flat faces are perpendicular to the z-axis.
    geometry_msgs/Pose pose
    
    # Radius of the cylinder at min z
    float64 bottom_radius
    
    # Radius of the cylinder at max z
    float64 top_radius
    
    # Height of the cylinder along the z axis
    float64 height
    
    # Color of the sphere
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: foxglove_msgs/KeyValuePair
    # foxglove_msgs/KeyValuePair
    # A key with its associated value
    
    # Generated by https://github.com/foxglove/schemas
    
    # Key
    string key
    
    # Value
    string value
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: foxglove_msgs/Color
    # foxglove_msgs/Color
    # A color in RGBA format
    
    # Generated by https://github.com/foxglove/schemas
    
    # Red value between 0 and 1
    float64 r
    
    # Green value between 0 and 1
    float64 g
    
    # Blue value between 0 and 1
    float64 b
    
    # Alpha value between 0 and 1
    float64 a
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CylinderMarker(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.frame_id !== undefined) {
      resolved.frame_id = msg.frame_id;
    }
    else {
      resolved.frame_id = ''
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = ''
    }

    if (msg.lifetime !== undefined) {
      resolved.lifetime = msg.lifetime;
    }
    else {
      resolved.lifetime = {secs: 0, nsecs: 0}
    }

    if (msg.frame_locked !== undefined) {
      resolved.frame_locked = msg.frame_locked;
    }
    else {
      resolved.frame_locked = false
    }

    if (msg.metadata !== undefined) {
      resolved.metadata = new Array(msg.metadata.length);
      for (let i = 0; i < resolved.metadata.length; ++i) {
        resolved.metadata[i] = KeyValuePair.Resolve(msg.metadata[i]);
      }
    }
    else {
      resolved.metadata = []
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.bottom_radius !== undefined) {
      resolved.bottom_radius = msg.bottom_radius;
    }
    else {
      resolved.bottom_radius = 0.0
    }

    if (msg.top_radius !== undefined) {
      resolved.top_radius = msg.top_radius;
    }
    else {
      resolved.top_radius = 0.0
    }

    if (msg.height !== undefined) {
      resolved.height = msg.height;
    }
    else {
      resolved.height = 0.0
    }

    if (msg.color !== undefined) {
      resolved.color = Color.Resolve(msg.color)
    }
    else {
      resolved.color = new Color()
    }

    return resolved;
    }
};

module.exports = CylinderMarker;
