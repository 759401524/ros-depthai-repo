// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CIRCLE_ANNOTATION_HPP_
#define FOXGLOVE_MSGS__MSG__CIRCLE_ANNOTATION_HPP_

#include "foxglove_msgs/msg/detail/circle_annotation__struct.hpp"
#include "foxglove_msgs/msg/detail/circle_annotation__builder.hpp"
#include "foxglove_msgs/msg/detail/circle_annotation__traits.hpp"

#endif  // FOXGLOVE_MSGS__MSG__CIRCLE_ANNOTATION_HPP_
