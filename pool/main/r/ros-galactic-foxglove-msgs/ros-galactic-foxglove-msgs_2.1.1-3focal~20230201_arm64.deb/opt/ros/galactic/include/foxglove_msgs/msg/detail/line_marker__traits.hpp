// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from foxglove_msgs:msg/LineMarker.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__LINE_MARKER__TRAITS_HPP_
#define FOXGLOVE_MSGS__MSG__DETAIL__LINE_MARKER__TRAITS_HPP_

#include "foxglove_msgs/msg/detail/line_marker__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__traits.hpp"
// Member 'points'
#include "geometry_msgs/msg/detail/point__traits.hpp"
// Member 'color'
// Member 'colors'
#include "foxglove_msgs/msg/detail/color__traits.hpp"

namespace rosidl_generator_traits
{

inline void to_yaml(
  const foxglove_msgs::msg::LineMarker & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    value_to_yaml(msg.type, out);
    out << "\n";
  }

  // member: pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pose:\n";
    to_yaml(msg.pose, out, indentation + 2);
  }

  // member: thickness
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "thickness: ";
    value_to_yaml(msg.thickness, out);
    out << "\n";
  }

  // member: scale_invariant
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "scale_invariant: ";
    value_to_yaml(msg.scale_invariant, out);
    out << "\n";
  }

  // member: points
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.points.size() == 0) {
      out << "points: []\n";
    } else {
      out << "points:\n";
      for (auto item : msg.points) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: color
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "color:\n";
    to_yaml(msg.color, out, indentation + 2);
  }

  // member: colors
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.colors.size() == 0) {
      out << "colors: []\n";
    } else {
      out << "colors:\n";
      for (auto item : msg.colors) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: indices
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.indices.size() == 0) {
      out << "indices: []\n";
    } else {
      out << "indices:\n";
      for (auto item : msg.indices) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const foxglove_msgs::msg::LineMarker & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<foxglove_msgs::msg::LineMarker>()
{
  return "foxglove_msgs::msg::LineMarker";
}

template<>
inline const char * name<foxglove_msgs::msg::LineMarker>()
{
  return "foxglove_msgs/msg/LineMarker";
}

template<>
struct has_fixed_size<foxglove_msgs::msg::LineMarker>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<foxglove_msgs::msg::LineMarker>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<foxglove_msgs::msg::LineMarker>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__LINE_MARKER__TRAITS_HPP_
