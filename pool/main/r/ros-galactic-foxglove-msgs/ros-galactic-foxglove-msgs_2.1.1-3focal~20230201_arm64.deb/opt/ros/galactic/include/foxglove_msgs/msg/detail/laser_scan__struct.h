// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/LaserScan.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__LASER_SCAN__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__LASER_SCAN__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'frame_id'
#include "rosidl_runtime_c/string.h"
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'ranges'
// Member 'intensities'
#include "rosidl_runtime_c/primitives_sequence.h"

// Struct defined in msg/LaserScan in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__LaserScan
{
  builtin_interfaces__msg__Time timestamp;
  rosidl_runtime_c__String frame_id;
  geometry_msgs__msg__Pose pose;
  double start_angle;
  double end_angle;
  rosidl_runtime_c__double__Sequence ranges;
  rosidl_runtime_c__double__Sequence intensities;
} foxglove_msgs__msg__LaserScan;

// Struct for a sequence of foxglove_msgs__msg__LaserScan.
typedef struct foxglove_msgs__msg__LaserScan__Sequence
{
  foxglove_msgs__msg__LaserScan * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__LaserScan__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__LASER_SCAN__STRUCT_H_
