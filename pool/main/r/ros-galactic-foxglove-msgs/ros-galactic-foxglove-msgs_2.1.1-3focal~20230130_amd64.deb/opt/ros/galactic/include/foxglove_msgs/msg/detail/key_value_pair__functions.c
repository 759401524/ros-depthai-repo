// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from foxglove_msgs:msg/KeyValuePair.idl
// generated code does not contain a copyright notice
#include "foxglove_msgs/msg/detail/key_value_pair__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `key`
// Member `value`
#include "rosidl_runtime_c/string_functions.h"

bool
foxglove_msgs__msg__KeyValuePair__init(foxglove_msgs__msg__KeyValuePair * msg)
{
  if (!msg) {
    return false;
  }
  // key
  if (!rosidl_runtime_c__String__init(&msg->key)) {
    foxglove_msgs__msg__KeyValuePair__fini(msg);
    return false;
  }
  // value
  if (!rosidl_runtime_c__String__init(&msg->value)) {
    foxglove_msgs__msg__KeyValuePair__fini(msg);
    return false;
  }
  return true;
}

void
foxglove_msgs__msg__KeyValuePair__fini(foxglove_msgs__msg__KeyValuePair * msg)
{
  if (!msg) {
    return;
  }
  // key
  rosidl_runtime_c__String__fini(&msg->key);
  // value
  rosidl_runtime_c__String__fini(&msg->value);
}

bool
foxglove_msgs__msg__KeyValuePair__are_equal(const foxglove_msgs__msg__KeyValuePair * lhs, const foxglove_msgs__msg__KeyValuePair * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // key
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->key), &(rhs->key)))
  {
    return false;
  }
  // value
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->value), &(rhs->value)))
  {
    return false;
  }
  return true;
}

bool
foxglove_msgs__msg__KeyValuePair__copy(
  const foxglove_msgs__msg__KeyValuePair * input,
  foxglove_msgs__msg__KeyValuePair * output)
{
  if (!input || !output) {
    return false;
  }
  // key
  if (!rosidl_runtime_c__String__copy(
      &(input->key), &(output->key)))
  {
    return false;
  }
  // value
  if (!rosidl_runtime_c__String__copy(
      &(input->value), &(output->value)))
  {
    return false;
  }
  return true;
}

foxglove_msgs__msg__KeyValuePair *
foxglove_msgs__msg__KeyValuePair__create()
{
  foxglove_msgs__msg__KeyValuePair * msg = (foxglove_msgs__msg__KeyValuePair *)malloc(sizeof(foxglove_msgs__msg__KeyValuePair));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(foxglove_msgs__msg__KeyValuePair));
  bool success = foxglove_msgs__msg__KeyValuePair__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
foxglove_msgs__msg__KeyValuePair__destroy(foxglove_msgs__msg__KeyValuePair * msg)
{
  if (msg) {
    foxglove_msgs__msg__KeyValuePair__fini(msg);
  }
  free(msg);
}


bool
foxglove_msgs__msg__KeyValuePair__Sequence__init(foxglove_msgs__msg__KeyValuePair__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  foxglove_msgs__msg__KeyValuePair * data = NULL;
  if (size) {
    data = (foxglove_msgs__msg__KeyValuePair *)calloc(size, sizeof(foxglove_msgs__msg__KeyValuePair));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = foxglove_msgs__msg__KeyValuePair__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        foxglove_msgs__msg__KeyValuePair__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
foxglove_msgs__msg__KeyValuePair__Sequence__fini(foxglove_msgs__msg__KeyValuePair__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      foxglove_msgs__msg__KeyValuePair__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

foxglove_msgs__msg__KeyValuePair__Sequence *
foxglove_msgs__msg__KeyValuePair__Sequence__create(size_t size)
{
  foxglove_msgs__msg__KeyValuePair__Sequence * array = (foxglove_msgs__msg__KeyValuePair__Sequence *)malloc(sizeof(foxglove_msgs__msg__KeyValuePair__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = foxglove_msgs__msg__KeyValuePair__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
foxglove_msgs__msg__KeyValuePair__Sequence__destroy(foxglove_msgs__msg__KeyValuePair__Sequence * array)
{
  if (array) {
    foxglove_msgs__msg__KeyValuePair__Sequence__fini(array);
  }
  free(array);
}

bool
foxglove_msgs__msg__KeyValuePair__Sequence__are_equal(const foxglove_msgs__msg__KeyValuePair__Sequence * lhs, const foxglove_msgs__msg__KeyValuePair__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!foxglove_msgs__msg__KeyValuePair__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
foxglove_msgs__msg__KeyValuePair__Sequence__copy(
  const foxglove_msgs__msg__KeyValuePair__Sequence * input,
  foxglove_msgs__msg__KeyValuePair__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(foxglove_msgs__msg__KeyValuePair);
    foxglove_msgs__msg__KeyValuePair * data =
      (foxglove_msgs__msg__KeyValuePair *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!foxglove_msgs__msg__KeyValuePair__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          foxglove_msgs__msg__KeyValuePair__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!foxglove_msgs__msg__KeyValuePair__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
