// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/LineMarker.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__LINE_MARKER__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__LINE_MARKER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'LINE_STRIP'.
enum
{
  foxglove_msgs__msg__LineMarker__LINE_STRIP = 0
};

/// Constant 'LINE_LOOP'.
enum
{
  foxglove_msgs__msg__LineMarker__LINE_LOOP = 1
};

/// Constant 'LINE_LIST'.
enum
{
  foxglove_msgs__msg__LineMarker__LINE_LIST = 2
};

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'points'
#include "geometry_msgs/msg/detail/point__struct.h"
// Member 'color'
// Member 'colors'
#include "foxglove_msgs/msg/detail/color__struct.h"
// Member 'indices'
#include "rosidl_runtime_c/primitives_sequence.h"

// Struct defined in msg/LineMarker in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__LineMarker
{
  uint8_t type;
  geometry_msgs__msg__Pose pose;
  double thickness;
  bool scale_invariant;
  geometry_msgs__msg__Point__Sequence points;
  foxglove_msgs__msg__Color color;
  foxglove_msgs__msg__Color__Sequence colors;
  rosidl_runtime_c__uint32__Sequence indices;
} foxglove_msgs__msg__LineMarker;

// Struct for a sequence of foxglove_msgs__msg__LineMarker.
typedef struct foxglove_msgs__msg__LineMarker__Sequence
{
  foxglove_msgs__msg__LineMarker * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__LineMarker__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__LINE_MARKER__STRUCT_H_
