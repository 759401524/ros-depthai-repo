// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/PointsAnnotation.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__POINTS_ANNOTATION__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__POINTS_ANNOTATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNKNOWN'.
enum
{
  foxglove_msgs__msg__PointsAnnotation__UNKNOWN = 0
};

/// Constant 'POINTS'.
enum
{
  foxglove_msgs__msg__PointsAnnotation__POINTS = 1
};

/// Constant 'LINE_LOOP'.
enum
{
  foxglove_msgs__msg__PointsAnnotation__LINE_LOOP = 2
};

/// Constant 'LINE_STRIP'.
enum
{
  foxglove_msgs__msg__PointsAnnotation__LINE_STRIP = 3
};

/// Constant 'LINE_LIST'.
enum
{
  foxglove_msgs__msg__PointsAnnotation__LINE_LIST = 4
};

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'points'
#include "foxglove_msgs/msg/detail/point2__struct.h"
// Member 'outline_color'
// Member 'outline_colors'
// Member 'fill_color'
#include "foxglove_msgs/msg/detail/color__struct.h"

// Struct defined in msg/PointsAnnotation in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__PointsAnnotation
{
  builtin_interfaces__msg__Time timestamp;
  uint8_t type;
  foxglove_msgs__msg__Point2__Sequence points;
  foxglove_msgs__msg__Color outline_color;
  foxglove_msgs__msg__Color__Sequence outline_colors;
  foxglove_msgs__msg__Color fill_color;
  double thickness;
} foxglove_msgs__msg__PointsAnnotation;

// Struct for a sequence of foxglove_msgs__msg__PointsAnnotation.
typedef struct foxglove_msgs__msg__PointsAnnotation__Sequence
{
  foxglove_msgs__msg__PointsAnnotation * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__PointsAnnotation__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__POINTS_ANNOTATION__STRUCT_H_
