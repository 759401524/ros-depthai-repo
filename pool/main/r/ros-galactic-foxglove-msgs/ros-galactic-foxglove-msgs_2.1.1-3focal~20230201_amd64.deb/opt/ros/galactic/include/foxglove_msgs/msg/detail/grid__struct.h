// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/Grid.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__GRID__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__GRID__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'frame_id'
#include "rosidl_runtime_c/string.h"
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'cell_size'
#include "foxglove_msgs/msg/detail/vector2__struct.h"
// Member 'fields'
#include "foxglove_msgs/msg/detail/packed_element_field__struct.h"
// Member 'data'
#include "rosidl_runtime_c/primitives_sequence.h"

// Struct defined in msg/Grid in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__Grid
{
  builtin_interfaces__msg__Time timestamp;
  rosidl_runtime_c__String frame_id;
  geometry_msgs__msg__Pose pose;
  uint32_t column_count;
  foxglove_msgs__msg__Vector2 cell_size;
  uint32_t row_stride;
  uint32_t cell_stride;
  foxglove_msgs__msg__PackedElementField__Sequence fields;
  rosidl_runtime_c__uint8__Sequence data;
} foxglove_msgs__msg__Grid;

// Struct for a sequence of foxglove_msgs__msg__Grid.
typedef struct foxglove_msgs__msg__Grid__Sequence
{
  foxglove_msgs__msg__Grid * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__Grid__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__GRID__STRUCT_H_
