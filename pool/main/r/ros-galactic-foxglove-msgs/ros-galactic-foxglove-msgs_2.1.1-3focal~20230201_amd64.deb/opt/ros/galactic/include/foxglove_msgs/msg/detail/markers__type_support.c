// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from foxglove_msgs:msg/Markers.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "foxglove_msgs/msg/detail/markers__rosidl_typesupport_introspection_c.h"
#include "foxglove_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "foxglove_msgs/msg/detail/markers__functions.h"
#include "foxglove_msgs/msg/detail/markers__struct.h"


// Include directives for member types
// Member `deletions`
#include "foxglove_msgs/msg/marker_deletion.h"
// Member `deletions`
#include "foxglove_msgs/msg/detail/marker_deletion__rosidl_typesupport_introspection_c.h"
// Member `arrows`
#include "foxglove_msgs/msg/arrow_marker.h"
// Member `arrows`
#include "foxglove_msgs/msg/detail/arrow_marker__rosidl_typesupport_introspection_c.h"
// Member `cubes`
#include "foxglove_msgs/msg/cube_list_marker.h"
// Member `cubes`
#include "foxglove_msgs/msg/detail/cube_list_marker__rosidl_typesupport_introspection_c.h"
// Member `spheres`
#include "foxglove_msgs/msg/sphere_list_marker.h"
// Member `spheres`
#include "foxglove_msgs/msg/detail/sphere_list_marker__rosidl_typesupport_introspection_c.h"
// Member `cones`
#include "foxglove_msgs/msg/cone_list_marker.h"
// Member `cones`
#include "foxglove_msgs/msg/detail/cone_list_marker__rosidl_typesupport_introspection_c.h"
// Member `lines`
#include "foxglove_msgs/msg/line_marker.h"
// Member `lines`
#include "foxglove_msgs/msg/detail/line_marker__rosidl_typesupport_introspection_c.h"
// Member `triangles`
#include "foxglove_msgs/msg/triangle_list_marker.h"
// Member `triangles`
#include "foxglove_msgs/msg/detail/triangle_list_marker__rosidl_typesupport_introspection_c.h"
// Member `texts`
#include "foxglove_msgs/msg/text_marker.h"
// Member `texts`
#include "foxglove_msgs/msg/detail/text_marker__rosidl_typesupport_introspection_c.h"
// Member `models`
#include "foxglove_msgs/msg/model_marker.h"
// Member `models`
#include "foxglove_msgs/msg/detail/model_marker__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void Markers__rosidl_typesupport_introspection_c__Markers_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  foxglove_msgs__msg__Markers__init(message_memory);
}

void Markers__rosidl_typesupport_introspection_c__Markers_fini_function(void * message_memory)
{
  foxglove_msgs__msg__Markers__fini(message_memory);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__MarkerDeletion__deletions(
  const void * untyped_member)
{
  const foxglove_msgs__msg__MarkerDeletion__Sequence * member =
    (const foxglove_msgs__msg__MarkerDeletion__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__MarkerDeletion__deletions(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__MarkerDeletion__Sequence * member =
    (const foxglove_msgs__msg__MarkerDeletion__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__MarkerDeletion__deletions(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__MarkerDeletion__Sequence * member =
    (foxglove_msgs__msg__MarkerDeletion__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__MarkerDeletion__deletions(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__MarkerDeletion__Sequence * member =
    (foxglove_msgs__msg__MarkerDeletion__Sequence *)(untyped_member);
  foxglove_msgs__msg__MarkerDeletion__Sequence__fini(member);
  return foxglove_msgs__msg__MarkerDeletion__Sequence__init(member, size);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__ArrowMarker__arrows(
  const void * untyped_member)
{
  const foxglove_msgs__msg__ArrowMarker__Sequence * member =
    (const foxglove_msgs__msg__ArrowMarker__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__ArrowMarker__arrows(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__ArrowMarker__Sequence * member =
    (const foxglove_msgs__msg__ArrowMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__ArrowMarker__arrows(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__ArrowMarker__Sequence * member =
    (foxglove_msgs__msg__ArrowMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__ArrowMarker__arrows(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__ArrowMarker__Sequence * member =
    (foxglove_msgs__msg__ArrowMarker__Sequence *)(untyped_member);
  foxglove_msgs__msg__ArrowMarker__Sequence__fini(member);
  return foxglove_msgs__msg__ArrowMarker__Sequence__init(member, size);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__CubeListMarker__cubes(
  const void * untyped_member)
{
  const foxglove_msgs__msg__CubeListMarker__Sequence * member =
    (const foxglove_msgs__msg__CubeListMarker__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__CubeListMarker__cubes(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__CubeListMarker__Sequence * member =
    (const foxglove_msgs__msg__CubeListMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__CubeListMarker__cubes(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__CubeListMarker__Sequence * member =
    (foxglove_msgs__msg__CubeListMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__CubeListMarker__cubes(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__CubeListMarker__Sequence * member =
    (foxglove_msgs__msg__CubeListMarker__Sequence *)(untyped_member);
  foxglove_msgs__msg__CubeListMarker__Sequence__fini(member);
  return foxglove_msgs__msg__CubeListMarker__Sequence__init(member, size);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__SphereListMarker__spheres(
  const void * untyped_member)
{
  const foxglove_msgs__msg__SphereListMarker__Sequence * member =
    (const foxglove_msgs__msg__SphereListMarker__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__SphereListMarker__spheres(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__SphereListMarker__Sequence * member =
    (const foxglove_msgs__msg__SphereListMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__SphereListMarker__spheres(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__SphereListMarker__Sequence * member =
    (foxglove_msgs__msg__SphereListMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__SphereListMarker__spheres(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__SphereListMarker__Sequence * member =
    (foxglove_msgs__msg__SphereListMarker__Sequence *)(untyped_member);
  foxglove_msgs__msg__SphereListMarker__Sequence__fini(member);
  return foxglove_msgs__msg__SphereListMarker__Sequence__init(member, size);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__ConeListMarker__cones(
  const void * untyped_member)
{
  const foxglove_msgs__msg__ConeListMarker__Sequence * member =
    (const foxglove_msgs__msg__ConeListMarker__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__ConeListMarker__cones(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__ConeListMarker__Sequence * member =
    (const foxglove_msgs__msg__ConeListMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__ConeListMarker__cones(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__ConeListMarker__Sequence * member =
    (foxglove_msgs__msg__ConeListMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__ConeListMarker__cones(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__ConeListMarker__Sequence * member =
    (foxglove_msgs__msg__ConeListMarker__Sequence *)(untyped_member);
  foxglove_msgs__msg__ConeListMarker__Sequence__fini(member);
  return foxglove_msgs__msg__ConeListMarker__Sequence__init(member, size);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__LineMarker__lines(
  const void * untyped_member)
{
  const foxglove_msgs__msg__LineMarker__Sequence * member =
    (const foxglove_msgs__msg__LineMarker__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__LineMarker__lines(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__LineMarker__Sequence * member =
    (const foxglove_msgs__msg__LineMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__LineMarker__lines(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__LineMarker__Sequence * member =
    (foxglove_msgs__msg__LineMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__LineMarker__lines(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__LineMarker__Sequence * member =
    (foxglove_msgs__msg__LineMarker__Sequence *)(untyped_member);
  foxglove_msgs__msg__LineMarker__Sequence__fini(member);
  return foxglove_msgs__msg__LineMarker__Sequence__init(member, size);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__TriangleListMarker__triangles(
  const void * untyped_member)
{
  const foxglove_msgs__msg__TriangleListMarker__Sequence * member =
    (const foxglove_msgs__msg__TriangleListMarker__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__TriangleListMarker__triangles(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__TriangleListMarker__Sequence * member =
    (const foxglove_msgs__msg__TriangleListMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__TriangleListMarker__triangles(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__TriangleListMarker__Sequence * member =
    (foxglove_msgs__msg__TriangleListMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__TriangleListMarker__triangles(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__TriangleListMarker__Sequence * member =
    (foxglove_msgs__msg__TriangleListMarker__Sequence *)(untyped_member);
  foxglove_msgs__msg__TriangleListMarker__Sequence__fini(member);
  return foxglove_msgs__msg__TriangleListMarker__Sequence__init(member, size);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__TextMarker__texts(
  const void * untyped_member)
{
  const foxglove_msgs__msg__TextMarker__Sequence * member =
    (const foxglove_msgs__msg__TextMarker__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__TextMarker__texts(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__TextMarker__Sequence * member =
    (const foxglove_msgs__msg__TextMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__TextMarker__texts(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__TextMarker__Sequence * member =
    (foxglove_msgs__msg__TextMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__TextMarker__texts(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__TextMarker__Sequence * member =
    (foxglove_msgs__msg__TextMarker__Sequence *)(untyped_member);
  foxglove_msgs__msg__TextMarker__Sequence__fini(member);
  return foxglove_msgs__msg__TextMarker__Sequence__init(member, size);
}

size_t Markers__rosidl_typesupport_introspection_c__size_function__ModelMarker__models(
  const void * untyped_member)
{
  const foxglove_msgs__msg__ModelMarker__Sequence * member =
    (const foxglove_msgs__msg__ModelMarker__Sequence *)(untyped_member);
  return member->size;
}

const void * Markers__rosidl_typesupport_introspection_c__get_const_function__ModelMarker__models(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__ModelMarker__Sequence * member =
    (const foxglove_msgs__msg__ModelMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

void * Markers__rosidl_typesupport_introspection_c__get_function__ModelMarker__models(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__ModelMarker__Sequence * member =
    (foxglove_msgs__msg__ModelMarker__Sequence *)(untyped_member);
  return &member->data[index];
}

bool Markers__rosidl_typesupport_introspection_c__resize_function__ModelMarker__models(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__ModelMarker__Sequence * member =
    (foxglove_msgs__msg__ModelMarker__Sequence *)(untyped_member);
  foxglove_msgs__msg__ModelMarker__Sequence__fini(member);
  return foxglove_msgs__msg__ModelMarker__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[9] = {
  {
    "deletions",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, deletions),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__MarkerDeletion__deletions,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__MarkerDeletion__deletions,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__MarkerDeletion__deletions,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__MarkerDeletion__deletions  // resize(index) function pointer
  },
  {
    "arrows",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, arrows),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__ArrowMarker__arrows,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__ArrowMarker__arrows,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__ArrowMarker__arrows,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__ArrowMarker__arrows  // resize(index) function pointer
  },
  {
    "cubes",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, cubes),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__CubeListMarker__cubes,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__CubeListMarker__cubes,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__CubeListMarker__cubes,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__CubeListMarker__cubes  // resize(index) function pointer
  },
  {
    "spheres",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, spheres),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__SphereListMarker__spheres,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__SphereListMarker__spheres,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__SphereListMarker__spheres,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__SphereListMarker__spheres  // resize(index) function pointer
  },
  {
    "cones",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, cones),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__ConeListMarker__cones,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__ConeListMarker__cones,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__ConeListMarker__cones,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__ConeListMarker__cones  // resize(index) function pointer
  },
  {
    "lines",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, lines),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__LineMarker__lines,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__LineMarker__lines,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__LineMarker__lines,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__LineMarker__lines  // resize(index) function pointer
  },
  {
    "triangles",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, triangles),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__TriangleListMarker__triangles,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__TriangleListMarker__triangles,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__TriangleListMarker__triangles,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__TriangleListMarker__triangles  // resize(index) function pointer
  },
  {
    "texts",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, texts),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__TextMarker__texts,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__TextMarker__texts,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__TextMarker__texts,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__TextMarker__texts  // resize(index) function pointer
  },
  {
    "models",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__Markers, models),  // bytes offset in struct
    NULL,  // default value
    Markers__rosidl_typesupport_introspection_c__size_function__ModelMarker__models,  // size() function pointer
    Markers__rosidl_typesupport_introspection_c__get_const_function__ModelMarker__models,  // get_const(index) function pointer
    Markers__rosidl_typesupport_introspection_c__get_function__ModelMarker__models,  // get(index) function pointer
    Markers__rosidl_typesupport_introspection_c__resize_function__ModelMarker__models  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers Markers__rosidl_typesupport_introspection_c__Markers_message_members = {
  "foxglove_msgs__msg",  // message namespace
  "Markers",  // message name
  9,  // number of fields
  sizeof(foxglove_msgs__msg__Markers),
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array,  // message members
  Markers__rosidl_typesupport_introspection_c__Markers_init_function,  // function to initialize message memory (memory has to be allocated)
  Markers__rosidl_typesupport_introspection_c__Markers_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t Markers__rosidl_typesupport_introspection_c__Markers_message_type_support_handle = {
  0,
  &Markers__rosidl_typesupport_introspection_c__Markers_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_foxglove_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, Markers)() {
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, MarkerDeletion)();
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, ArrowMarker)();
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, CubeListMarker)();
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, SphereListMarker)();
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, ConeListMarker)();
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, LineMarker)();
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[6].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, TriangleListMarker)();
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[7].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, TextMarker)();
  Markers__rosidl_typesupport_introspection_c__Markers_message_member_array[8].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, ModelMarker)();
  if (!Markers__rosidl_typesupport_introspection_c__Markers_message_type_support_handle.typesupport_identifier) {
    Markers__rosidl_typesupport_introspection_c__Markers_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &Markers__rosidl_typesupport_introspection_c__Markers_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
