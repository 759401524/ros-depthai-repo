// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from foxglove_msgs:msg/SceneEntities.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__SCENE_ENTITIES__TRAITS_HPP_
#define FOXGLOVE_MSGS__MSG__DETAIL__SCENE_ENTITIES__TRAITS_HPP_

#include "foxglove_msgs/msg/detail/scene_entities__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'deletions'
#include "foxglove_msgs/msg/detail/scene_entity_deletion__traits.hpp"
// Member 'entities'
#include "foxglove_msgs/msg/detail/scene_entity__traits.hpp"

namespace rosidl_generator_traits
{

inline void to_yaml(
  const foxglove_msgs::msg::SceneEntities & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: deletions
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.deletions.size() == 0) {
      out << "deletions: []\n";
    } else {
      out << "deletions:\n";
      for (auto item : msg.deletions) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: entities
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.entities.size() == 0) {
      out << "entities: []\n";
    } else {
      out << "entities:\n";
      for (auto item : msg.entities) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const foxglove_msgs::msg::SceneEntities & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<foxglove_msgs::msg::SceneEntities>()
{
  return "foxglove_msgs::msg::SceneEntities";
}

template<>
inline const char * name<foxglove_msgs::msg::SceneEntities>()
{
  return "foxglove_msgs/msg/SceneEntities";
}

template<>
struct has_fixed_size<foxglove_msgs::msg::SceneEntities>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<foxglove_msgs::msg::SceneEntities>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<foxglove_msgs::msg::SceneEntities>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__SCENE_ENTITIES__TRAITS_HPP_
