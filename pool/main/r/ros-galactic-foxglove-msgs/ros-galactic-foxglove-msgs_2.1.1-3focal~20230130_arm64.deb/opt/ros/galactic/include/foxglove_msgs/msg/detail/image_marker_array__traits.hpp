// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from foxglove_msgs:msg/ImageMarkerArray.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__IMAGE_MARKER_ARRAY__TRAITS_HPP_
#define FOXGLOVE_MSGS__MSG__DETAIL__IMAGE_MARKER_ARRAY__TRAITS_HPP_

#include "foxglove_msgs/msg/detail/image_marker_array__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'markers'
#include "visualization_msgs/msg/detail/image_marker__traits.hpp"

namespace rosidl_generator_traits
{

inline void to_yaml(
  const foxglove_msgs::msg::ImageMarkerArray & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: markers
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.markers.size() == 0) {
      out << "markers: []\n";
    } else {
      out << "markers:\n";
      for (auto item : msg.markers) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const foxglove_msgs::msg::ImageMarkerArray & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<foxglove_msgs::msg::ImageMarkerArray>()
{
  return "foxglove_msgs::msg::ImageMarkerArray";
}

template<>
inline const char * name<foxglove_msgs::msg::ImageMarkerArray>()
{
  return "foxglove_msgs/msg/ImageMarkerArray";
}

template<>
struct has_fixed_size<foxglove_msgs::msg::ImageMarkerArray>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<foxglove_msgs::msg::ImageMarkerArray>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<foxglove_msgs::msg::ImageMarkerArray>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__IMAGE_MARKER_ARRAY__TRAITS_HPP_
