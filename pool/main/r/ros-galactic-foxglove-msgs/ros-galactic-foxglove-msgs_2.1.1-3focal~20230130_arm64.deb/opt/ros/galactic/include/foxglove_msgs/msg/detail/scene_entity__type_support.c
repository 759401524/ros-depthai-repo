// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from foxglove_msgs:msg/SceneEntity.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "foxglove_msgs/msg/detail/scene_entity__rosidl_typesupport_introspection_c.h"
#include "foxglove_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "foxglove_msgs/msg/detail/scene_entity__functions.h"
#include "foxglove_msgs/msg/detail/scene_entity__struct.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/time.h"
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__rosidl_typesupport_introspection_c.h"
// Member `frame_id`
// Member `id`
#include "rosidl_runtime_c/string_functions.h"
// Member `lifetime`
#include "builtin_interfaces/msg/duration.h"
// Member `lifetime`
#include "builtin_interfaces/msg/detail/duration__rosidl_typesupport_introspection_c.h"
// Member `metadata`
#include "foxglove_msgs/msg/key_value_pair.h"
// Member `metadata`
#include "foxglove_msgs/msg/detail/key_value_pair__rosidl_typesupport_introspection_c.h"
// Member `arrows`
#include "foxglove_msgs/msg/arrow_primitive.h"
// Member `arrows`
#include "foxglove_msgs/msg/detail/arrow_primitive__rosidl_typesupport_introspection_c.h"
// Member `cubes`
#include "foxglove_msgs/msg/cube_primitive.h"
// Member `cubes`
#include "foxglove_msgs/msg/detail/cube_primitive__rosidl_typesupport_introspection_c.h"
// Member `spheres`
#include "foxglove_msgs/msg/sphere_primitive.h"
// Member `spheres`
#include "foxglove_msgs/msg/detail/sphere_primitive__rosidl_typesupport_introspection_c.h"
// Member `cylinders`
#include "foxglove_msgs/msg/cylinder_primitive.h"
// Member `cylinders`
#include "foxglove_msgs/msg/detail/cylinder_primitive__rosidl_typesupport_introspection_c.h"
// Member `lines`
#include "foxglove_msgs/msg/line_primitive.h"
// Member `lines`
#include "foxglove_msgs/msg/detail/line_primitive__rosidl_typesupport_introspection_c.h"
// Member `triangles`
#include "foxglove_msgs/msg/triangle_list_primitive.h"
// Member `triangles`
#include "foxglove_msgs/msg/detail/triangle_list_primitive__rosidl_typesupport_introspection_c.h"
// Member `texts`
#include "foxglove_msgs/msg/text_primitive.h"
// Member `texts`
#include "foxglove_msgs/msg/detail/text_primitive__rosidl_typesupport_introspection_c.h"
// Member `models`
#include "foxglove_msgs/msg/model_primitive.h"
// Member `models`
#include "foxglove_msgs/msg/detail/model_primitive__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  foxglove_msgs__msg__SceneEntity__init(message_memory);
}

void SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_fini_function(void * message_memory)
{
  foxglove_msgs__msg__SceneEntity__fini(message_memory);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__KeyValuePair__metadata(
  const void * untyped_member)
{
  const foxglove_msgs__msg__KeyValuePair__Sequence * member =
    (const foxglove_msgs__msg__KeyValuePair__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__KeyValuePair__metadata(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__KeyValuePair__Sequence * member =
    (const foxglove_msgs__msg__KeyValuePair__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__KeyValuePair__metadata(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__KeyValuePair__Sequence * member =
    (foxglove_msgs__msg__KeyValuePair__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__KeyValuePair__metadata(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__KeyValuePair__Sequence * member =
    (foxglove_msgs__msg__KeyValuePair__Sequence *)(untyped_member);
  foxglove_msgs__msg__KeyValuePair__Sequence__fini(member);
  return foxglove_msgs__msg__KeyValuePair__Sequence__init(member, size);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__ArrowPrimitive__arrows(
  const void * untyped_member)
{
  const foxglove_msgs__msg__ArrowPrimitive__Sequence * member =
    (const foxglove_msgs__msg__ArrowPrimitive__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__ArrowPrimitive__arrows(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__ArrowPrimitive__Sequence * member =
    (const foxglove_msgs__msg__ArrowPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__ArrowPrimitive__arrows(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__ArrowPrimitive__Sequence * member =
    (foxglove_msgs__msg__ArrowPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__ArrowPrimitive__arrows(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__ArrowPrimitive__Sequence * member =
    (foxglove_msgs__msg__ArrowPrimitive__Sequence *)(untyped_member);
  foxglove_msgs__msg__ArrowPrimitive__Sequence__fini(member);
  return foxglove_msgs__msg__ArrowPrimitive__Sequence__init(member, size);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__CubePrimitive__cubes(
  const void * untyped_member)
{
  const foxglove_msgs__msg__CubePrimitive__Sequence * member =
    (const foxglove_msgs__msg__CubePrimitive__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__CubePrimitive__cubes(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__CubePrimitive__Sequence * member =
    (const foxglove_msgs__msg__CubePrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__CubePrimitive__cubes(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__CubePrimitive__Sequence * member =
    (foxglove_msgs__msg__CubePrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__CubePrimitive__cubes(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__CubePrimitive__Sequence * member =
    (foxglove_msgs__msg__CubePrimitive__Sequence *)(untyped_member);
  foxglove_msgs__msg__CubePrimitive__Sequence__fini(member);
  return foxglove_msgs__msg__CubePrimitive__Sequence__init(member, size);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__SpherePrimitive__spheres(
  const void * untyped_member)
{
  const foxglove_msgs__msg__SpherePrimitive__Sequence * member =
    (const foxglove_msgs__msg__SpherePrimitive__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__SpherePrimitive__spheres(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__SpherePrimitive__Sequence * member =
    (const foxglove_msgs__msg__SpherePrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__SpherePrimitive__spheres(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__SpherePrimitive__Sequence * member =
    (foxglove_msgs__msg__SpherePrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__SpherePrimitive__spheres(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__SpherePrimitive__Sequence * member =
    (foxglove_msgs__msg__SpherePrimitive__Sequence *)(untyped_member);
  foxglove_msgs__msg__SpherePrimitive__Sequence__fini(member);
  return foxglove_msgs__msg__SpherePrimitive__Sequence__init(member, size);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__CylinderPrimitive__cylinders(
  const void * untyped_member)
{
  const foxglove_msgs__msg__CylinderPrimitive__Sequence * member =
    (const foxglove_msgs__msg__CylinderPrimitive__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__CylinderPrimitive__cylinders(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__CylinderPrimitive__Sequence * member =
    (const foxglove_msgs__msg__CylinderPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__CylinderPrimitive__cylinders(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__CylinderPrimitive__Sequence * member =
    (foxglove_msgs__msg__CylinderPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__CylinderPrimitive__cylinders(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__CylinderPrimitive__Sequence * member =
    (foxglove_msgs__msg__CylinderPrimitive__Sequence *)(untyped_member);
  foxglove_msgs__msg__CylinderPrimitive__Sequence__fini(member);
  return foxglove_msgs__msg__CylinderPrimitive__Sequence__init(member, size);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__LinePrimitive__lines(
  const void * untyped_member)
{
  const foxglove_msgs__msg__LinePrimitive__Sequence * member =
    (const foxglove_msgs__msg__LinePrimitive__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__LinePrimitive__lines(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__LinePrimitive__Sequence * member =
    (const foxglove_msgs__msg__LinePrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__LinePrimitive__lines(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__LinePrimitive__Sequence * member =
    (foxglove_msgs__msg__LinePrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__LinePrimitive__lines(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__LinePrimitive__Sequence * member =
    (foxglove_msgs__msg__LinePrimitive__Sequence *)(untyped_member);
  foxglove_msgs__msg__LinePrimitive__Sequence__fini(member);
  return foxglove_msgs__msg__LinePrimitive__Sequence__init(member, size);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__TriangleListPrimitive__triangles(
  const void * untyped_member)
{
  const foxglove_msgs__msg__TriangleListPrimitive__Sequence * member =
    (const foxglove_msgs__msg__TriangleListPrimitive__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__TriangleListPrimitive__triangles(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__TriangleListPrimitive__Sequence * member =
    (const foxglove_msgs__msg__TriangleListPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__TriangleListPrimitive__triangles(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__TriangleListPrimitive__Sequence * member =
    (foxglove_msgs__msg__TriangleListPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__TriangleListPrimitive__triangles(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__TriangleListPrimitive__Sequence * member =
    (foxglove_msgs__msg__TriangleListPrimitive__Sequence *)(untyped_member);
  foxglove_msgs__msg__TriangleListPrimitive__Sequence__fini(member);
  return foxglove_msgs__msg__TriangleListPrimitive__Sequence__init(member, size);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__TextPrimitive__texts(
  const void * untyped_member)
{
  const foxglove_msgs__msg__TextPrimitive__Sequence * member =
    (const foxglove_msgs__msg__TextPrimitive__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__TextPrimitive__texts(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__TextPrimitive__Sequence * member =
    (const foxglove_msgs__msg__TextPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__TextPrimitive__texts(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__TextPrimitive__Sequence * member =
    (foxglove_msgs__msg__TextPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__TextPrimitive__texts(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__TextPrimitive__Sequence * member =
    (foxglove_msgs__msg__TextPrimitive__Sequence *)(untyped_member);
  foxglove_msgs__msg__TextPrimitive__Sequence__fini(member);
  return foxglove_msgs__msg__TextPrimitive__Sequence__init(member, size);
}

size_t SceneEntity__rosidl_typesupport_introspection_c__size_function__ModelPrimitive__models(
  const void * untyped_member)
{
  const foxglove_msgs__msg__ModelPrimitive__Sequence * member =
    (const foxglove_msgs__msg__ModelPrimitive__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntity__rosidl_typesupport_introspection_c__get_const_function__ModelPrimitive__models(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__ModelPrimitive__Sequence * member =
    (const foxglove_msgs__msg__ModelPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntity__rosidl_typesupport_introspection_c__get_function__ModelPrimitive__models(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__ModelPrimitive__Sequence * member =
    (foxglove_msgs__msg__ModelPrimitive__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntity__rosidl_typesupport_introspection_c__resize_function__ModelPrimitive__models(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__ModelPrimitive__Sequence * member =
    (foxglove_msgs__msg__ModelPrimitive__Sequence *)(untyped_member);
  foxglove_msgs__msg__ModelPrimitive__Sequence__fini(member);
  return foxglove_msgs__msg__ModelPrimitive__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[14] = {
  {
    "timestamp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, timestamp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "frame_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, frame_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lifetime",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, lifetime),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "frame_locked",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, frame_locked),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "metadata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, metadata),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__KeyValuePair__metadata,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__KeyValuePair__metadata,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__KeyValuePair__metadata,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__KeyValuePair__metadata  // resize(index) function pointer
  },
  {
    "arrows",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, arrows),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__ArrowPrimitive__arrows,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__ArrowPrimitive__arrows,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__ArrowPrimitive__arrows,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__ArrowPrimitive__arrows  // resize(index) function pointer
  },
  {
    "cubes",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, cubes),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__CubePrimitive__cubes,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__CubePrimitive__cubes,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__CubePrimitive__cubes,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__CubePrimitive__cubes  // resize(index) function pointer
  },
  {
    "spheres",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, spheres),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__SpherePrimitive__spheres,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__SpherePrimitive__spheres,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__SpherePrimitive__spheres,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__SpherePrimitive__spheres  // resize(index) function pointer
  },
  {
    "cylinders",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, cylinders),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__CylinderPrimitive__cylinders,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__CylinderPrimitive__cylinders,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__CylinderPrimitive__cylinders,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__CylinderPrimitive__cylinders  // resize(index) function pointer
  },
  {
    "lines",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, lines),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__LinePrimitive__lines,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__LinePrimitive__lines,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__LinePrimitive__lines,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__LinePrimitive__lines  // resize(index) function pointer
  },
  {
    "triangles",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, triangles),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__TriangleListPrimitive__triangles,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__TriangleListPrimitive__triangles,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__TriangleListPrimitive__triangles,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__TriangleListPrimitive__triangles  // resize(index) function pointer
  },
  {
    "texts",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, texts),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__TextPrimitive__texts,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__TextPrimitive__texts,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__TextPrimitive__texts,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__TextPrimitive__texts  // resize(index) function pointer
  },
  {
    "models",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntity, models),  // bytes offset in struct
    NULL,  // default value
    SceneEntity__rosidl_typesupport_introspection_c__size_function__ModelPrimitive__models,  // size() function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_const_function__ModelPrimitive__models,  // get_const(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__get_function__ModelPrimitive__models,  // get(index) function pointer
    SceneEntity__rosidl_typesupport_introspection_c__resize_function__ModelPrimitive__models  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_members = {
  "foxglove_msgs__msg",  // message namespace
  "SceneEntity",  // message name
  14,  // number of fields
  sizeof(foxglove_msgs__msg__SceneEntity),
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array,  // message members
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_init_function,  // function to initialize message memory (memory has to be allocated)
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_type_support_handle = {
  0,
  &SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_foxglove_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, SceneEntity)() {
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, builtin_interfaces, msg, Time)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, builtin_interfaces, msg, Duration)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, KeyValuePair)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[6].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, ArrowPrimitive)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[7].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, CubePrimitive)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[8].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, SpherePrimitive)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[9].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, CylinderPrimitive)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[10].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, LinePrimitive)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[11].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, TriangleListPrimitive)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[12].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, TextPrimitive)();
  SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_member_array[13].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, ModelPrimitive)();
  if (!SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_type_support_handle.typesupport_identifier) {
    SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &SceneEntity__rosidl_typesupport_introspection_c__SceneEntity_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
