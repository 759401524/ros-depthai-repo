
"use strict";

let TriggerNamed = require('./TriggerNamed.js')
let NormalizedImageCrop = require('./NormalizedImageCrop.js')

module.exports = {
  TriggerNamed: TriggerNamed,
  NormalizedImageCrop: NormalizedImageCrop,
};
