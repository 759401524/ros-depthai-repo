// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/Log.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__LOG__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__LOG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNKNOWN'.
enum
{
  foxglove_msgs__msg__Log__UNKNOWN = 0
};

/// Constant 'DEBUG'.
enum
{
  foxglove_msgs__msg__Log__DEBUG = 1
};

/// Constant 'INFO'.
enum
{
  foxglove_msgs__msg__Log__INFO = 2
};

/// Constant 'WARNING'.
enum
{
  foxglove_msgs__msg__Log__WARNING = 3
};

/// Constant 'ERROR'.
enum
{
  foxglove_msgs__msg__Log__ERROR = 4
};

/// Constant 'FATAL'.
enum
{
  foxglove_msgs__msg__Log__FATAL = 5
};

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'message'
// Member 'name'
// Member 'file'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/Log in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__Log
{
  builtin_interfaces__msg__Time timestamp;
  uint8_t level;
  rosidl_runtime_c__String message;
  rosidl_runtime_c__String name;
  rosidl_runtime_c__String file;
  uint32_t line;
} foxglove_msgs__msg__Log;

// Struct for a sequence of foxglove_msgs__msg__Log.
typedef struct foxglove_msgs__msg__Log__Sequence
{
  foxglove_msgs__msg__Log * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__Log__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__LOG__STRUCT_H_
