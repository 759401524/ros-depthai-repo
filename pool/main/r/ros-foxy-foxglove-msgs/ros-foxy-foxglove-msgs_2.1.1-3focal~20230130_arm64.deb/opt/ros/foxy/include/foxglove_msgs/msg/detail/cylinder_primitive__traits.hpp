// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from foxglove_msgs:msg/CylinderPrimitive.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__CYLINDER_PRIMITIVE__TRAITS_HPP_
#define FOXGLOVE_MSGS__MSG__DETAIL__CYLINDER_PRIMITIVE__TRAITS_HPP_

#include "foxglove_msgs/msg/detail/cylinder_primitive__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__traits.hpp"
// Member 'size'
#include "geometry_msgs/msg/detail/vector3__traits.hpp"
// Member 'color'
#include "foxglove_msgs/msg/detail/color__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<foxglove_msgs::msg::CylinderPrimitive>()
{
  return "foxglove_msgs::msg::CylinderPrimitive";
}

template<>
inline const char * name<foxglove_msgs::msg::CylinderPrimitive>()
{
  return "foxglove_msgs/msg/CylinderPrimitive";
}

template<>
struct has_fixed_size<foxglove_msgs::msg::CylinderPrimitive>
  : std::integral_constant<bool, has_fixed_size<foxglove_msgs::msg::Color>::value && has_fixed_size<geometry_msgs::msg::Pose>::value && has_fixed_size<geometry_msgs::msg::Vector3>::value> {};

template<>
struct has_bounded_size<foxglove_msgs::msg::CylinderPrimitive>
  : std::integral_constant<bool, has_bounded_size<foxglove_msgs::msg::Color>::value && has_bounded_size<geometry_msgs::msg::Pose>::value && has_bounded_size<geometry_msgs::msg::Vector3>::value> {};

template<>
struct is_message<foxglove_msgs::msg::CylinderPrimitive>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__CYLINDER_PRIMITIVE__TRAITS_HPP_
