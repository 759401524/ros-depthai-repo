// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from foxglove_msgs:msg/CircleAnnotation.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__CIRCLE_ANNOTATION__TRAITS_HPP_
#define FOXGLOVE_MSGS__MSG__DETAIL__CIRCLE_ANNOTATION__TRAITS_HPP_

#include "foxglove_msgs/msg/detail/circle_annotation__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"
// Member 'position'
#include "foxglove_msgs/msg/detail/point2__traits.hpp"
// Member 'fill_color'
// Member 'outline_color'
#include "foxglove_msgs/msg/detail/color__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<foxglove_msgs::msg::CircleAnnotation>()
{
  return "foxglove_msgs::msg::CircleAnnotation";
}

template<>
inline const char * name<foxglove_msgs::msg::CircleAnnotation>()
{
  return "foxglove_msgs/msg/CircleAnnotation";
}

template<>
struct has_fixed_size<foxglove_msgs::msg::CircleAnnotation>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value && has_fixed_size<foxglove_msgs::msg::Color>::value && has_fixed_size<foxglove_msgs::msg::Point2>::value> {};

template<>
struct has_bounded_size<foxglove_msgs::msg::CircleAnnotation>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value && has_bounded_size<foxglove_msgs::msg::Color>::value && has_bounded_size<foxglove_msgs::msg::Point2>::value> {};

template<>
struct is_message<foxglove_msgs::msg::CircleAnnotation>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__CIRCLE_ANNOTATION__TRAITS_HPP_
