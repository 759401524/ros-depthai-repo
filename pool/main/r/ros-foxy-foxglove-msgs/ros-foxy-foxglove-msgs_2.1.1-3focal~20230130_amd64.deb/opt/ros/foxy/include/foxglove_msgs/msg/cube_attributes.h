// generated from rosidl_generator_c/resource/idl.h.em
// with input from foxglove_msgs:msg/CubeAttributes.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CUBE_ATTRIBUTES_H_
#define FOXGLOVE_MSGS__MSG__CUBE_ATTRIBUTES_H_

#include "foxglove_msgs/msg/detail/cube_attributes__struct.h"
#include "foxglove_msgs/msg/detail/cube_attributes__functions.h"
#include "foxglove_msgs/msg/detail/cube_attributes__type_support.h"

#endif  // FOXGLOVE_MSGS__MSG__CUBE_ATTRIBUTES_H_
