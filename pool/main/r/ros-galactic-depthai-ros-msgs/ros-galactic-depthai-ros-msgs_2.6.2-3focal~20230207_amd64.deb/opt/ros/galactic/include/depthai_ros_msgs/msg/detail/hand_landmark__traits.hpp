// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from depthai_ros_msgs:msg/HandLandmark.idl
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__MSG__DETAIL__HAND_LANDMARK__TRAITS_HPP_
#define DEPTHAI_ROS_MSGS__MSG__DETAIL__HAND_LANDMARK__TRAITS_HPP_

#include "depthai_ros_msgs/msg/detail/hand_landmark__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'landmark'
#include "geometry_msgs/msg/detail/pose2_d__traits.hpp"
// Member 'position'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace rosidl_generator_traits
{

inline void to_yaml(
  const depthai_ros_msgs::msg::HandLandmark & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: label
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "label: ";
    value_to_yaml(msg.label, out);
    out << "\n";
  }

  // member: lm_score
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lm_score: ";
    value_to_yaml(msg.lm_score, out);
    out << "\n";
  }

  // member: landmark
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.landmark.size() == 0) {
      out << "landmark: []\n";
    } else {
      out << "landmark:\n";
      for (auto item : msg.landmark) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position:\n";
    to_yaml(msg.position, out, indentation + 2);
  }

  // member: is_spatial
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_spatial: ";
    value_to_yaml(msg.is_spatial, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const depthai_ros_msgs::msg::HandLandmark & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<depthai_ros_msgs::msg::HandLandmark>()
{
  return "depthai_ros_msgs::msg::HandLandmark";
}

template<>
inline const char * name<depthai_ros_msgs::msg::HandLandmark>()
{
  return "depthai_ros_msgs/msg/HandLandmark";
}

template<>
struct has_fixed_size<depthai_ros_msgs::msg::HandLandmark>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<depthai_ros_msgs::msg::HandLandmark>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<depthai_ros_msgs::msg::HandLandmark>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DEPTHAI_ROS_MSGS__MSG__DETAIL__HAND_LANDMARK__TRAITS_HPP_
