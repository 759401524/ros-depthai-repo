// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__COMPRESSED_IMAGE_HPP_
#define FOXGLOVE_MSGS__MSG__COMPRESSED_IMAGE_HPP_

#include "foxglove_msgs/msg/detail/compressed_image__struct.hpp"
#include "foxglove_msgs/msg/detail/compressed_image__builder.hpp"
#include "foxglove_msgs/msg/detail/compressed_image__traits.hpp"

#endif  // FOXGLOVE_MSGS__MSG__COMPRESSED_IMAGE_HPP_
