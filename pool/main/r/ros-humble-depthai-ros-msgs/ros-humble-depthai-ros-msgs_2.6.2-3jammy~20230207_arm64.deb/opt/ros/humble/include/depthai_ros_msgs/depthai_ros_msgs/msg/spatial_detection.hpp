// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__MSG__SPATIAL_DETECTION_HPP_
#define DEPTHAI_ROS_MSGS__MSG__SPATIAL_DETECTION_HPP_

#include "depthai_ros_msgs/msg/detail/spatial_detection__struct.hpp"
#include "depthai_ros_msgs/msg/detail/spatial_detection__builder.hpp"
#include "depthai_ros_msgs/msg/detail/spatial_detection__traits.hpp"

#endif  // DEPTHAI_ROS_MSGS__MSG__SPATIAL_DETECTION_HPP_
