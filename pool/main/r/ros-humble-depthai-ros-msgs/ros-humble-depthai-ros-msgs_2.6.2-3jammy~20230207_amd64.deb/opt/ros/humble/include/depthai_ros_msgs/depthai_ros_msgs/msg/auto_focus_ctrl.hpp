// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__MSG__AUTO_FOCUS_CTRL_HPP_
#define DEPTHAI_ROS_MSGS__MSG__AUTO_FOCUS_CTRL_HPP_

#include "depthai_ros_msgs/msg/detail/auto_focus_ctrl__struct.hpp"
#include "depthai_ros_msgs/msg/detail/auto_focus_ctrl__builder.hpp"
#include "depthai_ros_msgs/msg/detail/auto_focus_ctrl__traits.hpp"

#endif  // DEPTHAI_ROS_MSGS__MSG__AUTO_FOCUS_CTRL_HPP_
